from pathlib import Path
import zipfile
import requests

URL = "https://archive.ics.uci.edu/static/public/791/metropt+3+dataset.zip"
DATA_DIR = Path("data")
ZIP_PATH = DATA_DIR / "metropt3.zip"
CSV_NAME = "MetroPT3(AirCompressor).csv"

def main():
    DATA_DIR.mkdir(exist_ok=True)
    target = DATA_DIR / CSV_NAME
    if target.exists():
        print(f"Dataset already exists: {target}")
        return
    print("Downloading MetroPT-3 from the UCI Machine Learning Repository...")
    with requests.get(URL, stream=True, timeout=120) as response:
        response.raise_for_status()
        with open(ZIP_PATH, "wb") as f:
            for chunk in response.iter_content(chunk_size=1024 * 1024):
                if chunk:
                    f.write(chunk)
    print("Extracting archive...")
    with zipfile.ZipFile(ZIP_PATH) as archive:
        matches = [n for n in archive.namelist() if n.lower().endswith(".csv")]
        if not matches:
            raise RuntimeError("No CSV file found in the UCI archive.")
        selected = next((n for n in matches if "aircompressor" in n.lower()), matches[0])
        with archive.open(selected) as src, open(target, "wb") as dst:
            while True:
                chunk = src.read(1024 * 1024)
                if not chunk:
                    break
                dst.write(chunk)
    ZIP_PATH.unlink(missing_ok=True)
    print(f"Dataset saved to {target}")

if __name__ == "__main__":
    main()
