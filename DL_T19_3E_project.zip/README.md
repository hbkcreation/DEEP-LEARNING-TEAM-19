# Team 19 — DL_T19_3E
## Anomaly Detection in Industrial IoT Sensor Streams Using Autoencoders
**Variant:** 3E — Metro Train Air Compressor  
**Course:** CM701PC Deep Learning / CM751PC Deep Learning Lab  
**Institution:** MGIT (Autonomous), Hyderabad

This project implements an unsupervised anomaly-warning pipeline for the MetroPT-3 air-compressor telemetry dataset. It compares a flattened-window Dense Autoencoder baseline with an LSTM sequence Autoencoder.

> **Important academic integrity note:** no experimental metric is pre-filled or fabricated. Run the pipeline to produce metrics from the downloaded dataset. The generated report tables and plots are based on those run outputs.

## 1. Project structure
```text
DL_T19_3E/
├── README.md
├── requirements.txt
├── config.json
├── run_project.py
├── download_data.py
├── src/
│   ├── data_utils.py
│   ├── models.py
│   ├── metrics.py
│   └── reporting.py
├── report/
│   └── REPORT_TEMPLATE.md
├── data/                 # downloaded CSV is placed here (not included)
└── outputs/              # generated metrics, plots and model files
```

## 2. Dataset
Use the **MetroPT-3 Dataset** from the UCI Machine Learning Repository:
https://archive.ics.uci.edu/dataset/791/metropt+3+dataset

The UCI dataset contains 1,516,948 observations from an operational metro-train air production unit. Signals include pressure, oil temperature, motor current, compressor/valve states and other digital sensor readings. The UCI page describes a recommended first-month training period and provides four reported air-leak failure intervals.

The raw dataset is not bundled because it is approximately 208 MB. Download it automatically:
```bash
python download_data.py
```
Or place `MetroPT3(AirCompressor).csv` in `data/`.

## 3. Environment setup
Python 3.10 or 3.11 is recommended.
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
source .venv/bin/activate

pip install -r requirements.txt
```

## 4. Run
```bash
python run_project.py
```
The pipeline:
1. Loads and sorts sensor records by timestamp.
2. Uses February 2020 as the normal-only training period.
3. Fits preprocessing only on the training portion.
4. Creates overlapping 30-reading windows (about five minutes at the dataset's approximately 10-second cadence).
5. Trains Dense and LSTM Autoencoders using only normal training windows.
6. Scores later windows using reconstruction error.
7. Tunes thresholds on the labelled evaluation period, separately reporting the best-F1 operating point and a cost-aware operating point.
8. Produces plots, metrics, a cost table and a draft report in `outputs/`.

The evaluation-period labels are derived from the UCI-reported failure intervals. They are **not** used to train either autoencoder.

## 5. Performance targets from the MGIT assignment
- Fault-event recall: at least 0.85.
- False alarms: fewer than 2 per 24 hours.
- Detection delay: under 5 minutes (or within 3 readings where applicable).
- Labelled fault data used for training: none.

The script reports each target independently. It does not claim that a target was met unless the measured result supports that conclusion.

## 6. Important methodology notes
- The UCI dataset's failure intervals are reported as air-leak events. The project labels a window positive if its timestamp interval overlaps one of those reported events.
- A window is scored at its ending timestamp. This makes detection-delay calculations explicit.
- The false-alarm count is calculated by merging consecutive predicted-positive windows into alarm episodes, then normalising by evaluated hours.
- The cost analysis uses the assignment's costs: ₹4,00,000 per missed fault event and ₹2,000 per false-alarm episode. This is a simplified event-level cost model, not a full maintenance economics model.
- Because the public dataset's sampling cadence can contain gaps, the code estimates the median timestamp interval and reports it.
- Threshold tuning uses the labelled evaluation portion, as allowed by the assignment for threshold tuning and testing. For a stricter final assessment, reserve a separate calibration period and a final untouched test period.

## 7. Team 19 details
| Roll number | Department-assigned role |
|---|---|
| 23261A6648 | Data Lead |
| 23261A6626 | Model Lead |
| 23261A6602 | Evaluation and Report Lead |

All members must contribute to coding, experiments and the report and must be prepared to explain the complete work in the viva. Update the contribution table in the final report to reflect actual work performed.

## 8. Expected generated outputs
- `outputs/metrics_summary.json`
- `outputs/threshold_comparison.csv`
- `outputs/cost_analysis.csv`
- `outputs/precision_recall.png`
- `outputs/confusion_matrices.png`
- `outputs/reconstruction_error.png`
- `outputs/model_comparison.csv`
- `outputs/experiment_report.md`
- `outputs/dense_autoencoder.keras`
- `outputs/lstm_autoencoder.keras`

## 9. Viva preparation
Be ready to explain:
1. Why an autoencoder trained only on normal data can assign higher reconstruction error to abnormal patterns.
2. Why a bottleneck that is too wide can learn an identity mapping.
3. Why a sequence model can learn temporal relationships that a simple dense model may not represent as naturally.
4. Why threshold selection trades recall against false alarms.
5. Why the best-F1 threshold may not minimise the operational cost.
6. Why test/fault labels are excluded from model training.

## 10. References
1. Davari, N., Veloso, B., Ribeiro, R. P., and Gama, J., “MetroPT-3 Dataset,” UCI Machine Learning Repository, DOI: 10.24432/C5VW3R, 2023.
2. Davari, N., Veloso, B., Ribeiro, R. P., Pereira, P. M., and Gama, J., “Predictive maintenance based on anomaly detection using deep learning for air production unit in the railway industry,” 2021 IEEE 8th International Conference on Data Science and Advanced Analytics.
3. Goodfellow, I., Bengio, Y., and Courville, A., *Deep Learning*, MIT Press, 2016, Chapter 14.
