"""Dense and LSTM autoencoders (both trained on normal windows only)."""
import tensorflow as tf
from tensorflow.keras import layers, models


def build_dense_autoencoder(sequence_length, n_features, bottleneck=16):
    """Baseline: flatten the window, compress to a small bottleneck, reconstruct."""
    inp = layers.Input(shape=(sequence_length, n_features))
    x = layers.Flatten()(inp)
    x = layers.Dense(128, activation="relu")(x)
    x = layers.Dense(64, activation="relu")(x)
    x = layers.Dense(bottleneck, activation="relu", name="bottleneck")(x)
    x = layers.Dense(64, activation="relu")(x)
    x = layers.Dense(128, activation="relu")(x)
    x = layers.Dense(sequence_length * n_features, activation="linear")(x)
    out = layers.Reshape((sequence_length, n_features))(x)
    model = models.Model(inp, out, name="dense_autoencoder")
    model.compile(optimizer=tf.keras.optimizers.Adam(1e-3), loss="mse")
    return model


def build_lstm_autoencoder(sequence_length, n_features, latent_units=16):
    """Sequence autoencoder: LSTM encoder -> latent vector -> repeated -> LSTM decoder."""
    inp = layers.Input(shape=(sequence_length, n_features))
    x = layers.LSTM(64, return_sequences=True)(inp)
    x = layers.LSTM(latent_units, name="bottleneck")(x)
    x = layers.RepeatVector(sequence_length)(x)
    x = layers.LSTM(latent_units, return_sequences=True)(x)
    x = layers.LSTM(64, return_sequences=True)(x)
    out = layers.TimeDistributed(layers.Dense(n_features))(x)
    model = models.Model(inp, out, name="lstm_autoencoder")
    model.compile(optimizer=tf.keras.optimizers.Adam(1e-3), loss="mse")
    return model
