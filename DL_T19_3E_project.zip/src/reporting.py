"""Generate a draft experiment report from the measured results only."""
import math


def _md_table(df):
    cols = list(df.columns)
    lines = ["| " + " | ".join(cols) + " |", "|" + "|".join(["---"] * len(cols)) + "|"]
    for _, row in df.iterrows():
        cells = []
        for c in cols:
            v = row[c]
            if isinstance(v, float):
                cells.append("n/a" if math.isnan(v) else f"{v:.6g}")
            else:
                cells.append(str(v))
        lines.append("| " + " | ".join(cells) + " |")
    return "\n".join(lines)


def _yn(flag):
    return "Met" if flag else "Not met"


def write_report(out, summary, comparison, cost_table, cfg):
    L = ["# Experiment report (auto-generated from the run outputs)", "",
         "Team 19 | Variant 3E | Anomaly detection in metro air-compressor sensor streams", "",
         "## Configuration",
         f"- Training period (normal only): {cfg['train_start']} to {cfg['train_end']}",
         f"- Window length: {cfg['sequence_length']} readings, stride {cfg['stride']}",
         f"- Epochs (max): {cfg['epochs']}, batch size {cfg['batch_size']}, seed {cfg['random_seed']}",
         f"- Costs: INR {cfg['missed_fault_cost_inr']:,} per missed fault, INR {cfg['false_alarm_cost_inr']:,} per false alarm", "",
         "## Model comparison", _md_table(comparison), "",
         "## Cost analysis", _md_table(cost_table), ""]
    for name, s in summary.items():
        ev = s["cost_threshold"]["event"]
        t = ev["targets_met"]
        f1 = s["best_f1"]
        L += [f"## {name}",
              f"- Best-F1 threshold {s['best_f1_threshold']:.6g}: F1 {f1['classification']['f1']:.4f}, "
              f"precision {f1['classification']['precision']:.4f}, recall {f1['classification']['recall']:.4f}; "
              f"event recall {f1['event']['fault_event_recall']:.2f}, "
              f"false alarms/24h {f1['event']['false_alarms_per_24h']:.2f}",
              f"- Cost-aware threshold {s['cost_threshold']['threshold']:.6g}: "
              f"{ev['fault_events_detected']}/{ev['fault_events_total']} fault events detected, "
              f"{ev['false_alarm_episodes']} false-alarm episodes, "
              f"{ev['false_alarms_per_24h']:.2f} per 24 h, "
              f"mean delay {ev['mean_detection_delay_minutes']:.2f} min, "
              f"estimated cost INR {s['cost_threshold']['estimated_cost_inr']:,}",
              f"- Rationale: {s['cost_threshold']['rationale']}",
              f"- Training: {s['history']['epochs_ran']} epochs, final train loss {s['history']['final_train_loss']:.6f}, "
              f"final validation loss {s['history']['final_val_loss']:.6f}",
              "- Assignment targets at the cost-aware threshold: "
              f"recall >= 0.85: {_yn(t['recall_ge_0.85'])}; "
              f"false alarms < 2/24h: {_yn(t['false_alarms_lt_2_per_24h'])}; "
              f"mean delay < 5 min: {_yn(t['mean_delay_lt_5_min'])}", "",
              "Per-event results:"]
        for e in ev["per_event"]:
            if not e.get("in_evaluation_data", True):
                L.append(f"  - {e['start']} to {e['end']}: no evaluation data")
            elif e["detected"]:
                L.append(f"  - {e['start']} to {e['end']}: detected, delay {e['detection_delay_minutes']:.2f} min")
            else:
                L.append(f"  - {e['start']} to {e['end']}: missed")
        L.append("")
    L += ["## Caveats",
          "- Thresholds were tuned on the same labelled evaluation period used for reporting, so results are optimistic.",
          "- Only four failure intervals exist; event-level metrics have very coarse resolution.",
          "- Cost model is a simplified event-level model."]
    (out / "experiment_report.md").write_text("\n".join(L), encoding="utf-8")
