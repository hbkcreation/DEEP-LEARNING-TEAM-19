"""Scoring, threshold selection and event-level alarm metrics."""
import numpy as np
import pandas as pd
from sklearn.metrics import precision_recall_curve


def window_scores(model, X, batch_size=2048):
    """Mean squared reconstruction error per window."""
    scores = np.empty(len(X), dtype="float32")
    for i in range(0, len(X), batch_size):
        batch = X[i:i + batch_size]
        rec = model(batch, training=False).numpy()
        scores[i:i + batch_size] = np.mean((batch - rec) ** 2, axis=(1, 2))
    return scores


def classification_metrics(y_true, y_pred):
    y_true = np.asarray(y_true).astype(bool)
    y_pred = np.asarray(y_pred).astype(bool)
    tp = int(np.sum(y_true & y_pred)); fp = int(np.sum(~y_true & y_pred))
    fn = int(np.sum(y_true & ~y_pred)); tn = int(np.sum(~y_true & ~y_pred))
    precision = tp / (tp + fp) if (tp + fp) else 0.0
    recall = tp / (tp + fn) if (tp + fn) else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
    return {"precision": precision, "recall": recall, "f1": f1, "tp": tp, "fp": fp, "fn": fn, "tn": tn}


def event_alarm_metrics(y_true, y_pred, win_ends, failure_intervals, eval_hours):
    """Event-level metrics.

    - A fault event is detected if any predicted-positive window ends inside its interval.
    - Detection delay = first such window end minus the interval start.
    - Consecutive predicted-positive windows are merged into alarm episodes; an episode that
      never touches a failure interval is a false alarm.
    """
    pred = np.asarray(y_pred).astype(bool)
    ends = np.asarray(pd.DatetimeIndex(win_ends).values, dtype="datetime64[ns]")
    in_any = np.zeros(len(ends), dtype=bool)
    per_event, delays = [], []
    total = detected = 0
    for start, end in failure_intervals:
        s, e = np.datetime64(pd.Timestamp(start)), np.datetime64(pd.Timestamp(end))
        mask = (ends >= s) & (ends <= e)
        if not mask.any():
            per_event.append({"start": str(start), "end": str(end), "in_evaluation_data": False})
            continue
        in_any |= mask
        total += 1
        hits = np.flatnonzero(mask & pred)
        if len(hits):
            detected += 1
            delay_min = float((ends[hits[0]] - s) / np.timedelta64(1, "m"))
            delays.append(delay_min)
            per_event.append({"start": str(start), "end": str(end), "detected": True,
                              "detection_delay_minutes": delay_min})
        else:
            per_event.append({"start": str(start), "end": str(end), "detected": False})

    padded = np.concatenate([[0], pred.astype(np.int8), [0]])
    diff = np.diff(padded)
    ep_start = np.flatnonzero(diff == 1)
    ep_stop = np.flatnonzero(diff == -1)
    csum = np.concatenate([[0], np.cumsum(in_any)])
    touches_fault = (csum[ep_stop] - csum[ep_start]) > 0
    false_alarms = int(np.sum(~touches_fault))
    mean_delay = float(np.mean(delays)) if delays else float("nan")
    recall = detected / total if total else 0.0
    fa_per_24h = false_alarms / eval_hours * 24
    return {
        "fault_events_total": total,
        "fault_events_detected": detected,
        "fault_event_recall": recall,
        "alarm_episodes_total": int(len(ep_start)),
        "false_alarm_episodes": false_alarms,
        "false_alarms_per_24h": fa_per_24h,
        "mean_detection_delay_minutes": mean_delay,
        "max_detection_delay_minutes": float(np.max(delays)) if delays else float("nan"),
        "per_event": per_event,
        "targets_met": {
            "recall_ge_0.85": bool(recall >= 0.85),
            "false_alarms_lt_2_per_24h": bool(fa_per_24h < 2),
            "mean_delay_lt_5_min": bool(delays and mean_delay < 5),
        },
    }


def choose_thresholds(y_true, scores, win_ends, failure_intervals, eval_hours, miss_cost, fa_cost):
    """Return (best_f1_threshold, cost_threshold, precision, recall, thresholds, rationale)."""
    precision, recall, thresholds = precision_recall_curve(y_true, scores)
    p, r = precision[:-1], recall[:-1]
    f1 = 2 * p * r / np.maximum(p + r, 1e-12)
    best_f1_th = float(thresholds[int(np.argmax(f1))])

    quantiles = np.concatenate([np.linspace(0.50, 0.99, 60), np.linspace(0.99, 0.99999, 140)])
    candidates = np.unique(np.concatenate([np.quantile(scores, quantiles), [best_f1_th]]))
    best_key, best_cost, cost_th = None, np.inf, float(candidates[0])
    for t in candidates:  # ascending
        m = event_alarm_metrics(y_true, scores >= t, win_ends, failure_intervals, eval_hours)
        missed = m["fault_events_total"] - m["fault_events_detected"]
        cost = missed * miss_cost + m["false_alarm_episodes"] * fa_cost
        delay = m["mean_detection_delay_minutes"]
        delay = float("inf") if np.isnan(delay) else delay
        key = (cost, delay, -t)  # lowest cost, then lowest mean detection delay, then highest threshold
        if best_key is None or key < best_key:
            best_key, best_cost, cost_th = key, cost, float(t)
    rationale = (f"Threshold minimising event-level cost = missed_events x {miss_cost:,} + "
                 f"false_alarm_episodes x {fa_cost:,} over {len(candidates)} candidate thresholds "
                 f"(minimum estimated cost INR {int(best_cost):,}; ties broken by lowest mean "
                 f"detection delay, then highest threshold).")
    return best_f1_th, cost_th, p, r, thresholds, rationale
