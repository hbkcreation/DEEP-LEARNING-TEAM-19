"""Data loading, labelling, scaling and windowing for MetroPT-3."""
import numpy as np
import pandas as pd
from numpy.lib.stride_tricks import sliding_window_view
from sklearn.preprocessing import StandardScaler


def load_data(path, timestamp_column="timestamp"):
    """Load the CSV, sort by time and return (df, timestamp_column, feature_columns)."""
    df = pd.read_csv(path)
    df = df.loc[:, ~df.columns.astype(str).str.match(r"^Unnamed", case=False)]
    if timestamp_column not in df.columns:
        raise KeyError(f"Timestamp column '{timestamp_column}' not found. Columns: {list(df.columns)}")
    df[timestamp_column] = pd.to_datetime(df[timestamp_column], errors="coerce")
    df = df.dropna(subset=[timestamp_column])
    feature_cols = [c for c in df.columns if c != timestamp_column]
    df[feature_cols] = df[feature_cols].apply(pd.to_numeric, errors="coerce")
    df = df.dropna(subset=feature_cols)
    df = df.drop_duplicates(subset=[timestamp_column]).sort_values(timestamp_column).reset_index(drop=True)
    return df, timestamp_column, feature_cols


def add_failure_labels(timestamps, failure_intervals):
    """Return an int8 array: 1 where the reading lies inside a reported failure interval."""
    t = pd.to_datetime(pd.Series(timestamps)).values
    labels = np.zeros(len(t), dtype=bool)
    for start, end in failure_intervals:
        labels |= (t >= np.datetime64(pd.Timestamp(start))) & (t <= np.datetime64(pd.Timestamp(end)))
    return labels.astype(np.int8)


def fit_scaler(train_df, feature_cols):
    """Fit a StandardScaler on the (normal-only) training portion."""
    scaler = StandardScaler()
    scaler.fit(train_df[feature_cols])
    return scaler


def make_windows(x, timestamps, labels, sequence_length, stride):
    """Create overlapping windows.

    Returns X (n, L, F), y (n,), window_starts, window_ends. A window is positive if
    any reading inside it is labelled as failure; it is scored at its ending timestamp.
    """
    x = np.asarray(x)
    n = len(x)
    if n < sequence_length:
        raise ValueError("Not enough rows to build a single window.")
    view = sliding_window_view(x, (sequence_length, x.shape[1]))[:, 0]
    idx = np.arange(0, n - sequence_length + 1, stride)
    X = np.ascontiguousarray(view[idx])
    ts = pd.Series(pd.to_datetime(pd.Series(timestamps).reset_index(drop=True)))
    starts = pd.DatetimeIndex(ts.iloc[idx].values)
    ends = pd.DatetimeIndex(ts.iloc[idx + sequence_length - 1].values)
    lab = np.asarray(labels).astype(np.int64)
    cs = np.concatenate([[0], np.cumsum(lab)])
    y = ((cs[idx + sequence_length] - cs[idx]) > 0).astype(np.int8)
    return X, y, starts, ends
