import os, json, random, warnings
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import tensorflow as tf
from sklearn.model_selection import train_test_split

from src.data_utils import load_data, add_failure_labels, make_windows, fit_scaler
from src.models import build_dense_autoencoder, build_lstm_autoencoder
from src.metrics import window_scores, choose_thresholds, event_alarm_metrics, classification_metrics
from src.reporting import write_report

warnings.filterwarnings("ignore", category=FutureWarning)

def main():
    cfg = json.loads(Path("config.json").read_text())
    out = Path("outputs"); out.mkdir(exist_ok=True)
    random.seed(cfg["random_seed"]); np.random.seed(cfg["random_seed"]); tf.random.set_seed(cfg["random_seed"])

    data_path = Path(cfg["data_path"])
    if not data_path.exists():
        raise FileNotFoundError(f"Dataset not found: {data_path}. Run `python download_data.py` first.")
    df, ts_col, feature_cols = load_data(data_path, cfg["timestamp_column"])
    print(f"Loaded {len(df):,} rows and {len(feature_cols)} sensor features.")
    cadence = df[ts_col].diff().dt.total_seconds().median()
    print(f"Median timestamp interval: {cadence:.2f} seconds")

    train_start, train_end = pd.Timestamp(cfg["train_start"]), pd.Timestamp(cfg["train_end"])
    train_df = df[(df[ts_col] >= train_start) & (df[ts_col] < train_end)].copy()
    if len(train_df) < cfg["sequence_length"] * 20:
        raise ValueError("Insufficient rows in the configured normal training period.")
    # Chronological train/validation split; fit scaler only on training portion.
    split = int(len(train_df) * (1 - cfg["validation_fraction"]))
    fit_df, val_df = train_df.iloc[:split], train_df.iloc[split:]
    scaler = fit_scaler(fit_df, feature_cols)
    x_fit = scaler.transform(fit_df[feature_cols]).astype("float32")
    x_val = scaler.transform(val_df[feature_cols]).astype("float32")
    dummy_fit = np.zeros(len(fit_df), dtype=np.int8)
    dummy_val = np.zeros(len(val_df), dtype=np.int8)
    X_train, _, _, _ = make_windows(x_fit, fit_df[ts_col].reset_index(drop=True), dummy_fit, cfg["sequence_length"], cfg["stride"])
    X_val, _, _, _ = make_windows(x_val, val_df[ts_col].reset_index(drop=True), dummy_val, cfg["sequence_length"], cfg["stride"])
    print(f"Training windows: {len(X_train):,}; validation windows: {len(X_val):,}")

    # The public UCI failure intervals are used only for evaluation/threshold tuning.
    eval_df = df[df[ts_col] >= train_end].copy().reset_index(drop=True)
    eval_labels = add_failure_labels(eval_df[ts_col], cfg["failure_intervals"])
    x_eval = scaler.transform(eval_df[feature_cols]).astype("float32")
    X_eval, y_eval, win_starts, win_ends = make_windows(
        x_eval, eval_df[ts_col], eval_labels, cfg["sequence_length"], cfg["stride"]
    )
    if len(np.unique(y_eval)) < 2:
        raise ValueError("Evaluation windows do not contain both normal and failure labels. Check failure intervals and timestamps.")
    eval_hours = max((win_ends[-1] - win_ends[0]).total_seconds() / 3600, 1e-9)

    models = {
        "Dense_AE": build_dense_autoencoder(cfg["sequence_length"], len(feature_cols)),
        "LSTM_AE": build_lstm_autoencoder(cfg["sequence_length"], len(feature_cols))
    }
    summary = {}
    comparison_rows = []
    for name, model in models.items():
        print(f"\nTraining {name}...")
        callbacks = [
            tf.keras.callbacks.EarlyStopping(monitor="val_loss", patience=4, restore_best_weights=True),
            tf.keras.callbacks.ReduceLROnPlateau(monitor="val_loss", patience=2, factor=0.5)
        ]
        history = model.fit(
            X_train, X_train, validation_data=(X_val, X_val),
            epochs=cfg["epochs"], batch_size=cfg["batch_size"],
            shuffle=True, callbacks=callbacks, verbose=2
        )
        model.save(str(out / f"{name.lower()}.keras"))
        scores = window_scores(model, X_eval)
        best_f1_th, cost_th, precision, recall, thresholds, rationale = choose_thresholds(
            y_eval, scores, win_ends, cfg["failure_intervals"], eval_hours,
            cfg["missed_fault_cost_inr"], cfg["false_alarm_cost_inr"]
        )
        pred_f1 = scores >= best_f1_th
        pred_cost = scores >= cost_th
        event_f1 = event_alarm_metrics(y_eval, pred_f1, win_ends, cfg["failure_intervals"], eval_hours)
        event_cost = event_alarm_metrics(y_eval, pred_cost, win_ends, cfg["failure_intervals"], eval_hours)
        cls_f1 = classification_metrics(y_eval, pred_f1)
        cls_cost = classification_metrics(y_eval, pred_cost)
        missed = event_cost["fault_events_total"] - event_cost["fault_events_detected"]
        total_cost = missed * cfg["missed_fault_cost_inr"] + event_cost["false_alarm_episodes"] * cfg["false_alarm_cost_inr"]
        summary[name] = {
            "best_f1_threshold": float(best_f1_th),
            "cost_threshold": {
                "threshold": float(cost_th),
                "rationale": rationale,
                "classification": cls_cost,
                "event": event_cost,
                "estimated_cost_inr": int(total_cost)
            },
            "best_f1": {"classification": cls_f1, "event": event_f1},
            "history": {"epochs_ran": len(history.history["loss"]), "final_train_loss": float(history.history["loss"][-1]), "final_val_loss": float(history.history["val_loss"][-1])}
        }
        comparison_rows.append({
            "Model": name,
            "Best-F1 threshold": best_f1_th,
            "Best-F1": cls_f1["f1"],
            "Best-F1 precision": cls_f1["precision"],
            "Best-F1 recall": cls_f1["recall"],
            "Cost threshold": cost_th,
            "Cost-threshold event recall": event_cost["fault_event_recall"],
            "False alarms / 24h": event_cost["false_alarms_per_24h"],
            "Mean detection delay (min)": event_cost["mean_detection_delay_minutes"],
            "Estimated event cost (INR)": total_cost
        })

        # Per-model plots
        plt.figure(figsize=(7,5))
        plt.plot(recall, precision, label=name)
        plt.scatter([cls_f1["recall"]], [cls_f1["precision"]], color="tab:green", zorder=5, s=70, label="Best-F1 threshold")
        plt.scatter([cls_cost["recall"]], [cls_cost["precision"]], color="tab:red", marker="s", zorder=5, s=70, label="Cost-aware threshold")
        plt.xlabel("Recall"); plt.ylabel("Precision"); plt.title(f"Precision–Recall: {name}")
        plt.grid(True, alpha=.3); plt.legend(); plt.tight_layout()
        plt.savefig(out / f"precision_recall_{name.lower()}.png", dpi=160); plt.close()

        plt.figure(figsize=(10,4))
        plt.plot(win_ends, scores, linewidth=.7, label="Reconstruction error")
        plt.axhline(cost_th, linestyle="--", label="Cost-aware threshold")
        plt.xlabel("Time"); plt.ylabel("Mean squared reconstruction error")
        plt.title(f"Reconstruction error over evaluation period: {name}")
        plt.legend(); plt.tight_layout()
        plt.savefig(out / f"reconstruction_error_{name.lower()}.png", dpi=160); plt.close()

        from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
        cm = confusion_matrix(y_eval, pred_cost, labels=[0,1])
        disp = ConfusionMatrixDisplay(cm, display_labels=["Normal", "Fault"])
        disp.plot(values_format="d"); plt.title(f"Cost-threshold confusion matrix: {name}")
        plt.tight_layout(); plt.savefig(out / f"confusion_matrix_{name.lower()}.png", dpi=160); plt.close()

    comparison = pd.DataFrame(comparison_rows)
    comparison.to_csv(out / "model_comparison.csv", index=False)
    comparison.to_csv(out / "threshold_comparison.csv", index=False)
    (out / "metrics_summary.json").write_text(json.dumps(summary, indent=2, default=str))
    cost_table = comparison[["Model", "Cost threshold", "Cost-threshold event recall", "False alarms / 24h", "Estimated event cost (INR)"]]
    cost_table.to_csv(out / "cost_analysis.csv", index=False)

    # Combined comparison plot
    plt.figure(figsize=(8,5))
    plt.bar(comparison["Model"], comparison["Cost-threshold event recall"])
    plt.axhline(.85, linestyle="--", label="Assignment target (0.85)")
    plt.ylabel("Fault-event recall"); plt.title("Event recall at cost-aware threshold")
    plt.legend(); plt.tight_layout(); plt.savefig(out / "model_comparison.png", dpi=160); plt.close()

    write_report(out, summary, comparison, cost_table, cfg)
    print("\nCompleted. Inspect the outputs/ directory and use actual generated values in the final submission.")
    print(comparison.to_string(index=False))

if __name__ == "__main__":
    main()
