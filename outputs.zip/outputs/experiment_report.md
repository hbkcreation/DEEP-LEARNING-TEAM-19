# Experiment report (auto-generated from the run outputs)

Team 19 | Variant 3E | Anomaly detection in metro air-compressor sensor streams

## Configuration
- Training period (normal only): 2020-02-01 00:00:00 to 2020-03-01 00:00:00
- Window length: 30 readings, stride 3
- Epochs (max): 20, batch size 256, seed 42
- Costs: INR 400,000 per missed fault, INR 2,000 per false alarm

## Model comparison
| Model | Best-F1 threshold | Best-F1 | Best-F1 precision | Best-F1 recall | Cost threshold | Cost-threshold event recall | False alarms / 24h | Mean detection delay (min) | Estimated event cost (INR) |
|---|---|---|---|---|---|---|---|---|---|
| Dense_AE | 42.2539 | 0.711349 | 0.567558 | 0.952723 | 46.4974 | 1 | 1.06524 | 50.4042 | 392000 |
| LSTM_AE | 28.5083 | 0.692204 | 0.5457 | 0.94624 | 34.7261 | 1 | 1.22829 | 73.4542 | 452000 |

## Cost analysis
| Model | Cost threshold | Cost-threshold event recall | False alarms / 24h | Estimated event cost (INR) |
|---|---|---|---|---|
| Dense_AE | 46.4974 | 1 | 1.06524 | 392000 |
| LSTM_AE | 34.7261 | 1 | 1.22829 | 452000 |

## Dense_AE
- Best-F1 threshold 42.2539: F1 0.7113, precision 0.5676, recall 0.9527; event recall 1.00, false alarms/24h 1.54
- Cost-aware threshold 46.4974: 4/4 fault events detected, 196 false-alarm episodes, 1.07 per 24 h, mean delay 50.40 min, estimated cost INR 392,000
- Rationale: Threshold minimising event-level cost = missed_events x 400,000 + false_alarm_episodes x 2,000 over 200 candidate thresholds (minimum estimated cost INR 392,000; ties broken by lowest mean detection delay, then highest threshold).
- Training: 20 epochs, final train loss 0.081299, final validation loss 0.063105
- Assignment targets at the cost-aware threshold: recall >= 0.85: Met; false alarms < 2/24h: Met; mean delay < 5 min: Not met

Per-event results:
  - 2020-04-18 00:00:00 to 2020-04-19 00:00:00: detected, delay 30.25 min
  - 2020-05-29 23:30:00 to 2020-05-30 06:00:00: detected, delay 0.45 min
  - 2020-06-05 10:00:00 to 2020-06-07 14:30:00: detected, delay 0.40 min
  - 2020-07-15 14:30:00 to 2020-07-15 19:00:00: detected, delay 170.52 min

## LSTM_AE
- Best-F1 threshold 28.5083: F1 0.6922, precision 0.5457, recall 0.9462; event recall 1.00, false alarms/24h 3.77
- Cost-aware threshold 34.7261: 4/4 fault events detected, 226 false-alarm episodes, 1.23 per 24 h, mean delay 73.45 min, estimated cost INR 452,000
- Rationale: Threshold minimising event-level cost = missed_events x 400,000 + false_alarm_episodes x 2,000 over 200 candidate thresholds (minimum estimated cost INR 452,000; ties broken by lowest mean detection delay, then highest threshold).
- Training: 20 epochs, final train loss 0.165764, final validation loss 0.114675
- Assignment targets at the cost-aware threshold: recall >= 0.85: Met; false alarms < 2/24h: Met; mean delay < 5 min: Not met

Per-event results:
  - 2020-04-18 00:00:00 to 2020-04-19 00:00:00: detected, delay 46.12 min
  - 2020-05-29 23:30:00 to 2020-05-30 06:00:00: detected, delay 76.78 min
  - 2020-06-05 10:00:00 to 2020-06-07 14:30:00: detected, delay 0.40 min
  - 2020-07-15 14:30:00 to 2020-07-15 19:00:00: detected, delay 170.52 min

## Caveats
- Thresholds were tuned on the same labelled evaluation period used for reporting, so results are optimistic.
- Only four failure intervals exist; event-level metrics have very coarse resolution.
- Cost model is a simplified event-level model.